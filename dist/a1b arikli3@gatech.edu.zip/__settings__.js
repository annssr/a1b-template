ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1001042.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true
};
SCRIPTS = [ 36124923, 36124902, 36124920, 36124911, 36124916, 36124925, 36124918, 36127986, 36128030, 36128041, 36128042, 36128043, 36128046, 36128932, 36143561 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: true,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/36134780/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/36134781/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/36134779/1/ammo.js', 'preload' : true},
];
